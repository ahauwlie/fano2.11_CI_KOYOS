<div class="container">
	<!-- Start Footer Top-->
	<div class="footer_top">
		<div class="row">
			<div class="col-lg-3 col-sm-6  wow fadeInUp ">
				<div class="border-left column">
					<a href="<?php echo site_url('Home'); ?>"><img src="<?php echo base_url('/inti/images/logo1.png'); ?>" alt="logo" class="img-fluid footer_logo"/></a>
					<p>Moto fano2.11...</p>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6  wow fadeInUp">
				<div class="border-left column">
					<h5 class="title_h5 text-capitalize">Butuh bantuan?</h5>
					<ul>
						<li><a href="javascript:void(0);">Chat Admin</a></li>
						<li><a href="my_account.html">Akun Saya</a></li>
						<li><a href="contactus.html">Kontak Kami</a></li>
						<li><a href="faq.html">FAQs</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6  wow fadeInUp">
				<div class="border-left column">
					<h5 class="title_h5 text-capitalize">Ketentuan</h5>
					<ul>
						<li><a href="shipping_information.html">Informasi Pengiriman</a></li>
						<li><a href="returns_exchanges.html">Pengembalian Barang</a></li>
						<li><a href="size_chart.html">Ketentuan Ukuran</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6  wow fadeInUp">
				<div class="border-left column">
					<h5 class="title_h5 text-capitalize">Tentang Kami</h5>
					<ul>
						<li><a href="we_are_<?php echo site_url('Home'); ?>">Fano 2.11</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!-- End Footer Top-->
	<!-- Start Footer Middle -->
	<div class="footer_middle border-top">
		<div class="row">
			<div class="col-sm-12 col-md-4  wow fadeInUp">
				<!-- <h5 class="title_h5 text-center">Shop With Confidence</h5>
					<p class="text-center">Lorem ipsum dolor si amet consecter. </p>
					<ul class="text-center payment_content">
					    <li><img src="<?php echo base_url('/inti/images/payments.png'); ?>" alt="payments" class="img-fluid" /></li>
					</ul> -->
			</div>
			<div class="col-sm-12 col-md-4  wow fadeInUp">
				<h5 class="title_h5 text-center text-capitalize">Sosial Media</h5>
				<p class="text-center">ffggstjygndgyrtjftr.</p>
				<ul class="text-center footer_social_icons">
					<li><a href="javascript:void(0);"><i class="flaticon-facebook vertical_middle"></i></a></li>
					<li><a href="javascript:void(0);"><i class="flaticon-pinterest vertical_middle"></i></a></li>
					<li><a href="javascript:void(0);"><i class="flaticon-instagram-logo vertical_middle"></i></a></li>
				</ul>
			</div>
			<div class="col-sm-12 col-md-4  wow fadeInUp">
				<!-- <h5 class="title_h5 text-center text-capitalize">Secure Shopping</h5>
					<p class="text-center">Lorem ipsum dolor si amet consecter.</p>
					<ul class="text-center shopping_content">
					    <li><img src="<?php echo base_url('/inti/images/certi.png'); ?>" alt="certi"/></li>
					    <li><img src="<?php echo base_url('/inti/images/comodo.png'); ?>" alt="comodo"/></li>
					</ul> -->
			</div>
		</div>
	</div>
	<!-- End Footer Middle -->
</div>
<!-- Start Footer Bottom -->
<div class="footer_bottom text-center container-fluid  wow fadeInUp">
	<div class="container"> 2020 &copy; Fano 2.11 All rights reserved.</div>
</div>
<!-- End Footer Bottom -->