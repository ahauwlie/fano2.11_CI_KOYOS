<link href="<?php echo base_url('/inti/css/bootstrap.css'); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('/inti/css/bootstrap-select.min.css'); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('/inti/css/flaticon.css'); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('/inti/css/owl.carousel.min.css'); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('/inti/css/owl.theme.default.min.css'); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('/inti/css/jquery-ui.css'); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('/inti/css/jquery.mCustomScrollbar.css'); ?>" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/inti/revolution/css/settings.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/inti/revolution/css/layers.css'); ?>">
<link href="<?php echo base_url('/inti/revolution/css/revolution.addon.particles.css'); ?>" rel="stylesheet" type="text/css"/> 
<link href="<?php echo base_url('/inti/css/jquery.countdownTimer.css'); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('/inti/css/slick.css'); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('/inti/css/comparison.css'); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('/inti/css/styles1.css'); ?>" rel="stylesheet" type="text/css"/>