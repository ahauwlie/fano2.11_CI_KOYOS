<script src="<?php echo base_url('/inti/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/popper.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/bootstrap-select.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/owl.carousel.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/jquery-ui.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/jquery.mCustomScrollbar.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/cookie.js'); ?>"></script> 
<script src="<?php echo base_url('/inti/revolution/js/jquery.themepunch.tools.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/revolution/js/jquery.themepunch.revolution.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/revolution/js/extensions/revolution.addon.particles.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('/inti/revolution/js/extensions/revolution.extension.parallax.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('/inti/revolution/js/extensions/revolution.extension.slideanims.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('/inti/revolution/js/extensions/revolution.extension.layeranimation.min.js'); ?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url('/inti/revolution/js/extensions/revolution.extension.navigation.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/imagesloaded.pkgd.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/wow.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/page-scroll.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/instafeed.min.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/jquery.countdownTimer.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('/inti/js/rotate.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('/inti/js/slick.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('/inti/js/comparison.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('/inti/js/custom.js'); ?>"></script>